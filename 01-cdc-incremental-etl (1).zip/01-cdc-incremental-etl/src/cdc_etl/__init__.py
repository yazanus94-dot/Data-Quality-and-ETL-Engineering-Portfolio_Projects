"""Incremental / CDC-style ETL into a Type 2 slowly changing dimension."""
