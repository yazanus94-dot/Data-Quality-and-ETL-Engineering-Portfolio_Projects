"""Deterministic sample data and a helper that simulates source-system changes."""
import sqlite3

SEED_ROWS = [
    (1, "Lina Haddad", "lina@example.com", "Amman", "2026-01-05T09:00:00"),
    (2, "Omar Nasser", "omar@example.com", "Irbid", "2026-01-05T09:05:00"),
    (3, "Sara Khoury", "sara@example.com", "Zarqa", "2026-01-06T10:00:00"),
    (4, "Yousef Barakat", "yousef@example.com", "Amman", "2026-01-07T11:30:00"),
    (5, "Hana Mansour", "hana@example.com", "Aqaba", "2026-01-08T08:15:00"),
]


def write_source(conn: sqlite3.Connection, customer_id, name, email, city, updated_at, deleted=0):
    """Write to the source table AND append the same version to the audit trail."""
    conn.execute(
        "INSERT INTO customers(customer_id,name,email,city,updated_at,is_deleted) VALUES(?,?,?,?,?,?) "
        "ON CONFLICT(customer_id) DO UPDATE SET name=excluded.name,email=excluded.email,"
        "city=excluded.city,updated_at=excluded.updated_at,is_deleted=excluded.is_deleted",
        (customer_id, name, email, city, updated_at, deleted),
    )
    conn.execute(
        "INSERT INTO customers_audit(customer_id,name,email,city,updated_at,is_deleted) VALUES(?,?,?,?,?,?)",
        (customer_id, name, email, city, updated_at, deleted),
    )


def seed_source(conn: sqlite3.Connection) -> None:
    for row in SEED_ROWS:
        write_source(conn, *row)


def simulate_changes(conn: sqlite3.Connection) -> None:
    """A second batch of source activity: a move, a new customer, a deletion, an email change."""
    write_source(conn, 2, "Omar Nasser", "omar@example.com", "Amman", "2026-02-01T09:00:00")
    write_source(conn, 6, "Rania Odeh", "rania@example.com", "Madaba", "2026-02-01T09:10:00")
    write_source(conn, 3, "Sara Khoury", "sara@example.com", "Zarqa", "2026-02-02T12:00:00", deleted=1)
    write_source(conn, 5, "Hana Mansour", "hana.m@example.com", "Aqaba", "2026-02-02T13:45:00")
