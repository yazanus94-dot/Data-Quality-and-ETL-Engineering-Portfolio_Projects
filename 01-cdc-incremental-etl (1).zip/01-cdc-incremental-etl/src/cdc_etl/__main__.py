"""Command line interface.  Quick start:  python -m cdc_etl demo"""
import argparse
import os

from . import etl, seed


def main(argv=None):
    p = argparse.ArgumentParser(prog="cdc_etl", description=__doc__)
    p.add_argument("command", choices=["seed", "simulate", "full", "history", "incremental", "report", "demo"])
    p.add_argument("--source", default="output/source.db")
    p.add_argument("--warehouse", default="output/warehouse.db")
    args = p.parse_args(argv)

    os.makedirs(os.path.dirname(args.source) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(args.warehouse) or ".", exist_ok=True)
    if args.command == "demo":  # always start the demo from a clean slate
        for path in (args.source, args.warehouse):
            if os.path.exists(path):
                os.remove(path)

    src, dwh = etl.connect(args.source), etl.connect(args.warehouse)
    etl.init_source(src)
    etl.init_warehouse(dwh)

    if args.command == "seed":
        seed.seed_source(src)
    elif args.command == "simulate":
        seed.simulate_changes(src)
    elif args.command == "full":
        print(etl.full_load(src, dwh).as_dict())
    elif args.command == "history":
        print(etl.history_load(src, dwh).as_dict())
    elif args.command == "incremental":
        print(etl.incremental_load(src, dwh).as_dict())
    elif args.command == "demo":
        seed.seed_source(src)
        print("initial full load   :", etl.full_load(src, dwh).as_dict())
        seed.simulate_changes(src)
        print("incremental load    :", etl.incremental_load(src, dwh).as_dict())
        print("re-run (idempotent) :", etl.incremental_load(src, dwh).as_dict())

    if args.command in ("report", "demo"):
        print("\ndim_customer (SCD Type 2)  id, name, email, city, valid_from, valid_to, current, deleted")
        for r in dwh.execute("SELECT customer_id,name,email,city,valid_from,valid_to,is_current,is_deleted "
                             "FROM dim_customer ORDER BY customer_id, valid_from"):
            print("  ", tuple(r))
        print("\netl_run_log  run, mode, status, read, inserted, updated, deleted, unchanged")
        for r in dwh.execute("SELECT run_id,mode,status,rows_read,inserted,updated,deleted,unchanged FROM etl_run_log"):
            print("  ", tuple(r))


if __name__ == "__main__":
    main()
