"""Core ETL logic: incremental (watermark + hash-diff CDC), full and history loads.

Design notes
------------
* Source: ``customers`` (current state) and ``customers_audit`` (every version ever written).
* Target: ``dim_customer`` as an SCD Type 2 dimension (one row per version).
* Change detection: SHA-256 hash of the tracked columns, compared with the current dimension row.
* Incremental extract uses ``updated_at >= watermark`` (not ``>``) so rows sharing the watermark
  timestamp are never missed; the hash comparison makes re-processing them harmless (idempotent).
* Each run is one transaction. On failure everything rolls back and the watermark does not move.
"""
from __future__ import annotations

import hashlib
import sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

TRACKED = ("name", "email", "city")
EPOCH = "1970-01-01T00:00:00"
OPEN_END = "9999-12-31T00:00:00"
JOB = "dim_customer"

SOURCE_DDL = """
CREATE TABLE IF NOT EXISTS customers (
    customer_id INTEGER PRIMARY KEY,
    name TEXT, email TEXT, city TEXT,
    updated_at TEXT NOT NULL,
    is_deleted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS customers_audit (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    name TEXT, email TEXT, city TEXT,
    updated_at TEXT NOT NULL,
    is_deleted INTEGER NOT NULL DEFAULT 0
);
"""

DWH_DDL = """
CREATE TABLE IF NOT EXISTS dim_customer (
    customer_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    name TEXT, email TEXT, city TEXT,
    row_hash TEXT NOT NULL,
    valid_from TEXT NOT NULL,
    valid_to TEXT NOT NULL,
    is_current INTEGER NOT NULL,
    is_deleted INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_dim_customer_current
    ON dim_customer(customer_id) WHERE is_current = 1;
CREATE TABLE IF NOT EXISTS etl_watermark (
    job_name TEXT PRIMARY KEY, last_loaded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS etl_run_log (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_name TEXT, mode TEXT, started_at TEXT, finished_at TEXT, status TEXT,
    rows_read INTEGER, inserted INTEGER, updated INTEGER, deleted INTEGER,
    unchanged INTEGER, error TEXT
);
"""


@dataclass
class RunStats:
    rows_read: int = 0
    inserted: int = 0
    updated: int = 0
    deleted: int = 0
    unchanged: int = 0

    def as_dict(self) -> dict:
        return asdict(self)


def connect(path: str) -> sqlite3.Connection:
    """Open a connection with manual transaction control."""
    conn = sqlite3.connect(path, isolation_level=None)
    conn.row_factory = sqlite3.Row
    return conn


def init_source(conn: sqlite3.Connection) -> None:
    conn.executescript(SOURCE_DDL)


def init_warehouse(conn: sqlite3.Connection) -> None:
    conn.executescript(DWH_DDL)


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def row_hash(row) -> str:
    payload = "|".join("" if row[c] is None else str(row[c]).strip() for c in TRACKED)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def get_watermark(dwh: sqlite3.Connection) -> str:
    r = dwh.execute("SELECT last_loaded_at FROM etl_watermark WHERE job_name=?", (JOB,)).fetchone()
    return r["last_loaded_at"] if r else EPOCH


def _set_watermark(dwh: sqlite3.Connection, value: str) -> None:
    dwh.execute(
        "INSERT INTO etl_watermark(job_name,last_loaded_at) VALUES(?,?) "
        "ON CONFLICT(job_name) DO UPDATE SET last_loaded_at=excluded.last_loaded_at",
        (JOB, value),
    )


def _current(dwh, customer_id):
    return dwh.execute(
        "SELECT * FROM dim_customer WHERE customer_id=? AND is_current=1", (customer_id,)
    ).fetchone()


def _expire(dwh, sk, at):
    dwh.execute("UPDATE dim_customer SET valid_to=?, is_current=0 WHERE customer_sk=?", (at, sk))


def _insert_version(dwh, row, at, deleted=False):
    dwh.execute(
        "INSERT INTO dim_customer(customer_id,name,email,city,row_hash,valid_from,valid_to,"
        "is_current,is_deleted) VALUES(?,?,?,?,?,?,?,1,?)",
        (row["customer_id"], row["name"], row["email"], row["city"], row_hash(row), at,
         OPEN_END, 1 if deleted else 0),
    )


def apply_change(dwh: sqlite3.Connection, row, stats: RunStats) -> None:
    """Apply one source row to the SCD2 dimension (insert / new version / delete / no-op)."""
    at = row["updated_at"]
    cur = _current(dwh, row["customer_id"])

    if row["is_deleted"]:
        if cur is not None and not cur["is_deleted"]:
            _expire(dwh, cur["customer_sk"], at)
            _insert_version(dwh, row, at, deleted=True)
            stats.deleted += 1
        else:
            stats.unchanged += 1
        return

    if cur is None:
        _insert_version(dwh, row, at)
        stats.inserted += 1
    elif cur["is_deleted"] or cur["row_hash"] != row_hash(row):
        _expire(dwh, cur["customer_sk"], at)
        _insert_version(dwh, row, at)
        stats.updated += 1
    else:
        stats.unchanged += 1


def _log(dwh, mode, started, status, stats, error=None):
    dwh.execute(
        "INSERT INTO etl_run_log(job_name,mode,started_at,finished_at,status,rows_read,inserted,"
        "updated,deleted,unchanged,error) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (JOB, mode, started, _now(), status, stats.rows_read, stats.inserted, stats.updated,
         stats.deleted, stats.unchanged, error),
    )


def _run(src, dwh, mode, fetch_rows, reset=False) -> RunStats:
    started, stats = _now(), RunStats()
    try:
        dwh.execute("BEGIN")
        if reset:
            dwh.execute("DELETE FROM dim_customer")
            dwh.execute("DELETE FROM etl_watermark WHERE job_name=?", (JOB,))
        wm = get_watermark(dwh)
        rows = fetch_rows(wm)
        for row in rows:
            stats.rows_read += 1
            apply_change(dwh, row, stats)
        if mode == "incremental":
            top = max((r["updated_at"] for r in rows), default=wm)
        else:
            top = src.execute("SELECT MAX(updated_at) AS m FROM customers").fetchone()["m"]
        if top:
            _set_watermark(dwh, top)
        dwh.execute("COMMIT")
    except Exception as exc:  # roll back data AND watermark together
        dwh.execute("ROLLBACK")
        _log(dwh, mode, started, "FAILED", stats, str(exc))
        raise
    _log(dwh, mode, started, "SUCCESS", stats)
    return stats


def incremental_load(src, dwh) -> RunStats:
    """Load only rows changed since the stored watermark."""
    def fetch(wm):
        return src.execute(
            "SELECT * FROM customers WHERE updated_at >= ? ORDER BY updated_at, customer_id", (wm,)
        ).fetchall()
    return _run(src, dwh, "incremental", fetch)


def full_load(src, dwh) -> RunStats:
    """Rebuild the dimension from the current source snapshot (one version per customer)."""
    def fetch(_wm):
        return src.execute("SELECT * FROM customers ORDER BY updated_at, customer_id").fetchall()
    return _run(src, dwh, "full", fetch, reset=True)


def history_load(src, dwh) -> RunStats:
    """Rebuild the dimension by replaying every version in the source audit table."""
    def fetch(_wm):
        return src.execute("SELECT * FROM customers_audit ORDER BY updated_at, audit_id").fetchall()
    return _run(src, dwh, "history", fetch, reset=True)
