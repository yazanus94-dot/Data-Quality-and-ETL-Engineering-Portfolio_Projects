# 01 - Incremental / CDC ETL into an SCD Type 2 dimension

A small, fully tested ETL pipeline in Python and SQL that loads a customer source into a
warehouse dimension while keeping full history.

## What it demonstrates

| Topic | Where |
|---|---|
| Incremental loads (watermark) | `incremental_load` in `src/cdc_etl/etl.py` |
| Change data capture (hash-diff) | `row_hash` and `apply_change` |
| Full load and history load | `full_load`, `history_load` (replays the source audit trail) |
| SCD Type 2 (valid_from / valid_to / is_current) | `dim_customer` table |
| Soft deletes and reinstatement | `is_deleted` handling in `apply_change` |
| Idempotent, restartable jobs | `>=` watermark plus hash compare; one transaction per run |
| Job audit and run log | `etl_run_log` table |
| ETL testing | `tests/test_etl.py` (8 tests, including failure rollback) |

## Run it

```bash
pip install -r requirements.txt
python run.py demo      # seed, full load, simulated changes, incremental load, report
pytest                  # run the test suite
```

Other commands: `seed`, `simulate`, `full`, `history`, `incremental`, `report`
(`--source` and `--warehouse` set the SQLite file paths).

## Design decisions

* **`>=` on the watermark.** A strict `>` can skip rows that share the watermark timestamp. Reading
  them again is safe because unchanged rows are detected by hash and ignored.
* **One transaction per run.** If any row fails, the data and the watermark roll back together, so a
  retry starts from the same point. The failure is still written to the run log.
* **Hash over tracked columns only.** Changes to non-tracked columns do not create new history.
* **Deletes are versions, not removals.** History stays queryable.

## Notes

SQLite is used so the project runs anywhere with no setup. The data is synthetic. The SQL is
standard; moving to SQL Server or PostgreSQL would mainly mean changing the upsert syntax and the
partial unique index.

## About this project

A personal learning and portfolio project with synthetic data, built to show my approach to ETL
design, data quality and testing. My professional background is in QA and test automation. It is
not a production system and does not claim experience with any specific enterprise tool.
