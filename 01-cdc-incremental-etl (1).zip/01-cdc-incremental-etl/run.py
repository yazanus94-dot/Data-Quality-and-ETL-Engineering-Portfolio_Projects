"""Convenience launcher so the CLI works without installing the package.

    python run.py demo
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from cdc_etl.__main__ import main  # noqa: E402

if __name__ == "__main__":
    main()
