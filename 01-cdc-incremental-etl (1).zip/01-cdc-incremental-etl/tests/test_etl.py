import pytest

from cdc_etl import etl, seed


@pytest.fixture
def env(tmp_path):
    src = etl.connect(str(tmp_path / "src.db"))
    dwh = etl.connect(str(tmp_path / "dwh.db"))
    etl.init_source(src)
    etl.init_warehouse(dwh)
    seed.seed_source(src)
    return src, dwh


def current(dwh):
    return {r["customer_id"]: r for r in dwh.execute("SELECT * FROM dim_customer WHERE is_current=1")}


def test_full_load_creates_one_current_row_per_customer(env):
    src, dwh = env
    stats = etl.full_load(src, dwh)
    assert stats.inserted == 5 and stats.rows_read == 5
    assert len(current(dwh)) == 5


def test_incremental_detects_insert_update_delete(env):
    src, dwh = env
    etl.full_load(src, dwh)
    seed.simulate_changes(src)
    s = etl.incremental_load(src, dwh)
    assert (s.inserted, s.updated, s.deleted) == (1, 2, 1)
    cur = current(dwh)
    assert cur[2]["city"] == "Amman"
    assert cur[3]["is_deleted"] == 1
    assert cur[6]["name"] == "Rania Odeh"


def test_scd2_keeps_history_with_non_overlapping_ranges(env):
    src, dwh = env
    etl.full_load(src, dwh)
    seed.simulate_changes(src)
    etl.incremental_load(src, dwh)
    versions = dwh.execute(
        "SELECT * FROM dim_customer WHERE customer_id=2 ORDER BY valid_from").fetchall()
    assert [v["city"] for v in versions] == ["Irbid", "Amman"]
    assert versions[0]["valid_to"] == versions[1]["valid_from"]
    assert versions[0]["is_current"] == 0 and versions[1]["is_current"] == 1


def test_rerun_is_idempotent(env):
    src, dwh = env
    etl.full_load(src, dwh)
    seed.simulate_changes(src)
    etl.incremental_load(src, dwh)
    before = dwh.execute("SELECT COUNT(*) c FROM dim_customer").fetchone()["c"]
    s = etl.incremental_load(src, dwh)
    after = dwh.execute("SELECT COUNT(*) c FROM dim_customer").fetchone()["c"]
    assert before == after
    assert (s.inserted, s.updated, s.deleted) == (0, 0, 0)


def test_no_changes_means_nothing_written(env):
    src, dwh = env
    etl.full_load(src, dwh)
    s = etl.incremental_load(src, dwh)
    assert s.inserted == s.updated == s.deleted == 0


def test_history_load_matches_incremental_result(env, tmp_path):
    src, dwh = env
    etl.full_load(src, dwh)
    seed.simulate_changes(src)
    etl.incremental_load(src, dwh)
    other = etl.connect(str(tmp_path / "dwh2.db"))
    etl.init_warehouse(other)
    etl.history_load(src, other)
    a = {k: (v["city"], v["email"], v["is_deleted"]) for k, v in current(dwh).items()}
    b = {k: (v["city"], v["email"], v["is_deleted"]) for k, v in current(other).items()}
    assert a == b


def test_failure_rolls_back_data_and_watermark(env, monkeypatch):
    src, dwh = env
    etl.full_load(src, dwh)
    wm_before = etl.get_watermark(dwh)
    seed.simulate_changes(src)

    calls = {"n": 0}
    real = etl.apply_change

    def boom(d, row, stats):
        calls["n"] += 1
        if calls["n"] == 2:
            raise RuntimeError("simulated failure")
        real(d, row, stats)

    monkeypatch.setattr(etl, "apply_change", boom)
    with pytest.raises(RuntimeError):
        etl.incremental_load(src, dwh)
    monkeypatch.setattr(etl, "apply_change", real)

    assert etl.get_watermark(dwh) == wm_before
    assert dwh.execute("SELECT COUNT(*) c FROM dim_customer").fetchone()["c"] == 5
    assert dwh.execute("SELECT status FROM etl_run_log ORDER BY run_id DESC").fetchone()["status"] == "FAILED"
    assert etl.incremental_load(src, dwh).rows_read == 4  # retry picks everything up


def test_deleted_customer_can_be_reinstated(env):
    src, dwh = env
    etl.full_load(src, dwh)
    seed.write_source(src, 1, "Lina Haddad", "lina@example.com", "Amman", "2026-03-01T00:00:00", deleted=1)
    etl.incremental_load(src, dwh)
    seed.write_source(src, 1, "Lina Haddad", "lina@example.com", "Amman", "2026-03-02T00:00:00")
    etl.incremental_load(src, dwh)
    assert current(dwh)[1]["is_deleted"] == 0
