"""Billing ETL: stage -> validate -> load a small star schema -> reconcile invoices to payments."""
