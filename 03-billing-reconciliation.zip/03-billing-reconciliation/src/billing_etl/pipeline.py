"""Billing and payments ETL with data-quality rules, rejects and reconciliation.

Flow
----
1. EXTRACT   raw CSV files -> staging tables (everything as text, nothing lost)
2. VALIDATE  business rules; failing rows go to ``etl_reject`` with a reason code
3. LOAD      dim_customer, fct_invoice, fct_payment (money stored as integer cents)
4. RECONCILE per-invoice balances and status, aging report, tie-out checks

The run is a full refresh: the target database is rebuilt every time, so the job is idempotent.
Money is never summed across currencies.
"""
from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

ALLOWED_CURRENCIES = {"USD", "EUR", "JOD", "AED"}
HERE = os.path.dirname(os.path.abspath(__file__))
SQL_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "sql"))

DDL = """
CREATE TABLE stg_customer (row_no INTEGER, customer_id TEXT, customer_name TEXT, country TEXT);
CREATE TABLE stg_invoice  (row_no INTEGER, invoice_id TEXT, customer_id TEXT, issue_date TEXT,
                           due_date TEXT, amount TEXT, currency TEXT);
CREATE TABLE stg_payment  (row_no INTEGER, payment_id TEXT, invoice_id TEXT, payment_date TEXT,
                           amount TEXT, currency TEXT);

CREATE TABLE dim_customer (customer_id INTEGER PRIMARY KEY, customer_name TEXT NOT NULL, country TEXT);
CREATE TABLE fct_invoice (
    invoice_id TEXT PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES dim_customer(customer_id),
    issue_date TEXT NOT NULL, due_date TEXT NOT NULL,
    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
    currency TEXT NOT NULL
);
CREATE TABLE fct_payment (
    payment_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL REFERENCES fct_invoice(invoice_id),
    payment_date TEXT NOT NULL,
    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
    currency TEXT NOT NULL
);
CREATE TABLE etl_reject (entity TEXT, source_key TEXT, reason TEXT, raw_row TEXT);

CREATE VIEW v_invoice_balance AS
SELECT i.invoice_id, i.customer_id, i.due_date, i.currency, i.amount_cents,
       COALESCE(SUM(p.amount_cents), 0)                      AS paid_cents,
       i.amount_cents - COALESCE(SUM(p.amount_cents), 0)     AS balance_cents,
       CASE
         WHEN COALESCE(SUM(p.amount_cents), 0) = 0                       THEN 'unpaid'
         WHEN COALESCE(SUM(p.amount_cents), 0) < i.amount_cents          THEN 'partial'
         WHEN COALESCE(SUM(p.amount_cents), 0) = i.amount_cents          THEN 'paid'
         ELSE 'overpaid'
       END AS status
FROM fct_invoice i
LEFT JOIN fct_payment p ON p.invoice_id = i.invoice_id
GROUP BY i.invoice_id;
"""


# ----------------------------------------------------------------------------- parsing
def parse_cents(text: str) -> int:
    """'1200.00' -> 120000. Raises ValueError for anything that is not a plain decimal number."""
    text = (text or "").strip()
    if not re.fullmatch(r"-?\d+(\.\d{1,2})?", text):
        raise ValueError(f"bad amount: {text!r}")
    return int((Decimal(text) * 100).to_integral_value())


def parse_date(text: str) -> str:
    try:
        return datetime.strptime((text or "").strip(), "%Y-%m-%d").date().isoformat()
    except ValueError as exc:
        raise ValueError(f"bad date: {text!r}") from exc


# ----------------------------------------------------------------------------- extract
def _read(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def extract(conn: sqlite3.Connection, data_dir: str) -> None:
    for n, r in enumerate(_read(os.path.join(data_dir, "customers.csv")), start=2):
        conn.execute("INSERT INTO stg_customer VALUES (?,?,?,?)",
                     (n, r["customer_id"], r["customer_name"], r["country"]))
    for n, r in enumerate(_read(os.path.join(data_dir, "invoices.csv")), start=2):
        conn.execute("INSERT INTO stg_invoice VALUES (?,?,?,?,?,?,?)",
                     (n, r["invoice_id"], r["customer_id"], r["issue_date"], r["due_date"],
                      r["amount"], r["currency"]))
    for n, r in enumerate(_read(os.path.join(data_dir, "payments.csv")), start=2):
        conn.execute("INSERT INTO stg_payment VALUES (?,?,?,?,?,?)",
                     (n, r["payment_id"], r["invoice_id"], r["payment_date"], r["amount"], r["currency"]))


# ----------------------------------------------------------------------------- validate + load
def _reject(conn, entity, key, reason, row):
    conn.execute("INSERT INTO etl_reject VALUES (?,?,?,?)",
                 (entity, key, reason, json.dumps(dict(row), sort_keys=True)))


def load_customers(conn) -> None:
    for r in conn.execute("SELECT * FROM stg_customer ORDER BY row_no").fetchall():
        if not r["customer_id"].strip().isdigit() or not r["customer_name"].strip():
            _reject(conn, "customer", r["customer_id"], "invalid_customer", r)
            continue
        conn.execute("INSERT OR IGNORE INTO dim_customer VALUES (?,?,?)",
                     (int(r["customer_id"]), r["customer_name"].strip(), r["country"].strip()))


def validate_invoice(conn, r, seen: set) -> tuple[str | None, dict]:
    """Return (reject_reason, parsed_values). First failing rule wins."""
    try:
        cents = parse_cents(r["amount"])
    except ValueError:
        return "invalid_amount", {}
    if cents <= 0:
        return "non_positive_amount", {}
    currency = r["currency"].strip().upper()
    if currency not in ALLOWED_CURRENCIES:
        return "unsupported_currency", {}
    try:
        issue, due = parse_date(r["issue_date"]), parse_date(r["due_date"])
    except ValueError:
        return "invalid_date", {}
    if due < issue:
        return "due_before_issue", {}
    if not r["customer_id"].strip().isdigit() or not conn.execute(
            "SELECT 1 FROM dim_customer WHERE customer_id=?", (int(r["customer_id"]),)).fetchone():
        return "unknown_customer", {}
    if r["invoice_id"].strip() in seen:
        return "duplicate_invoice", {}
    return None, {"cents": cents, "currency": currency, "issue": issue, "due": due}


def load_invoices(conn) -> None:
    seen: set[str] = set()
    for r in conn.execute("SELECT * FROM stg_invoice ORDER BY row_no").fetchall():
        reason, v = validate_invoice(conn, r, seen)
        if reason:
            _reject(conn, "invoice", r["invoice_id"], reason, r)
            continue
        seen.add(r["invoice_id"].strip())
        conn.execute("INSERT INTO fct_invoice VALUES (?,?,?,?,?,?)",
                     (r["invoice_id"].strip(), int(r["customer_id"]), v["issue"], v["due"],
                      v["cents"], v["currency"]))


def load_payments(conn) -> None:
    seen: set[str] = set()
    for r in conn.execute("SELECT * FROM stg_payment ORDER BY row_no").fetchall():
        reason, cents, pay_date = None, 0, ""
        try:
            cents = parse_cents(r["amount"])
            if cents <= 0:
                reason = "non_positive_amount"
        except ValueError:
            reason = "invalid_amount"
        if not reason:
            try:
                pay_date = parse_date(r["payment_date"])
            except ValueError:
                reason = "invalid_date"
        if not reason and r["payment_id"].strip() in seen:
            reason = "duplicate_payment"
        inv = None
        if not reason:
            inv = conn.execute("SELECT currency FROM fct_invoice WHERE invoice_id=?",
                               (r["invoice_id"].strip(),)).fetchone()
            if inv is None:
                reason = "unknown_invoice"
            elif inv["currency"] != r["currency"].strip().upper():
                reason = "currency_mismatch"
        if reason:
            _reject(conn, "payment", r["payment_id"], reason, r)
            continue
        seen.add(r["payment_id"].strip())
        conn.execute("INSERT INTO fct_payment VALUES (?,?,?,?,?)",
                     (r["payment_id"].strip(), r["invoice_id"].strip(), pay_date, cents,
                      r["currency"].strip().upper()))


# ----------------------------------------------------------------------------- reconcile
def _statements(path: str) -> list[str]:
    """Split a .sql file into statements, dropping comment lines."""
    lines = [ln for ln in open(path, encoding="utf-8").read().splitlines() if not ln.strip().startswith("--")]
    return [s.strip() for s in "\n".join(lines).split(";") if s.strip()]


def run_checks(conn) -> list[dict]:
    """Run sql/reconciliation_checks.sql. Each statement must return zero rows."""
    results = []
    for stmt in _statements(os.path.join(SQL_DIR, "reconciliation_checks.sql")):
        rows = conn.execute(stmt).fetchall()
        results.append({"check": stmt.splitlines()[0][:70], "violations": len(rows)})
    return results


def amount_tie_out(conn) -> dict:
    """Staged-and-valid money must equal loaded money, per currency, for invoices and payments."""
    out = {}
    for table, fact in (("stg_invoice", "fct_invoice"), ("stg_payment", "fct_payment")):
        staged = {}
        for r in conn.execute(f"SELECT amount, currency FROM {table}"):
            try:
                cents = parse_cents(r["amount"])
            except ValueError:
                continue
            staged[r["currency"]] = staged.get(r["currency"], 0) + cents
        loaded = {r["currency"]: r["s"] for r in conn.execute(
            f"SELECT currency, SUM(amount_cents) s FROM {fact} GROUP BY currency")}
        rejected = {}
        ent = "invoice" if fact == "fct_invoice" else "payment"
        for r in conn.execute("SELECT raw_row FROM etl_reject WHERE entity=?", (ent,)):
            row = json.loads(r["raw_row"])
            try:
                rejected[row["currency"]] = rejected.get(row["currency"], 0) + parse_cents(row["amount"])
            except ValueError:
                pass
        ok = all(staged.get(c, 0) == loaded.get(c, 0) + rejected.get(c, 0)
                 for c in set(staged) | set(loaded) | set(rejected))
        out[ent] = {"balanced": ok}
    return out


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def run(data_dir: str, out_dir: str, as_of: str | None = None) -> dict:
    as_of = parse_date(as_of or date.today().isoformat())
    os.makedirs(out_dir, exist_ok=True)
    db_path = os.path.join(out_dir, "warehouse.db")
    if os.path.exists(db_path):
        os.remove(db_path)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(DDL)

    with conn:  # one transaction for the whole load
        extract(conn, data_dir)
        load_customers(conn)
        load_invoices(conn)
        load_payments(conn)

    balances = conn.execute("SELECT * FROM v_invoice_balance ORDER BY invoice_id").fetchall()
    write_csv(os.path.join(out_dir, "reconciliation.csv"),
              ["invoice_id", "customer_id", "currency", "invoiced", "paid", "balance", "status"],
              [(b["invoice_id"], b["customer_id"], b["currency"], b["amount_cents"] / 100,
                b["paid_cents"] / 100, b["balance_cents"] / 100, b["status"]) for b in balances])

    aging_sql = _statements(os.path.join(SQL_DIR, "aging_report.sql"))[0]
    aging = conn.execute(aging_sql, {"as_of": as_of}).fetchall()
    write_csv(os.path.join(out_dir, "aging_report.csv"), aging[0].keys() if aging else [],
              [tuple(r) for r in aging])

    rejects = conn.execute("SELECT entity, source_key, reason, raw_row FROM etl_reject "
                           "ORDER BY entity, source_key").fetchall()
    write_csv(os.path.join(out_dir, "rejects.csv"), ["entity", "source_key", "reason", "raw_row"],
              [tuple(r) for r in rejects])

    count = lambda sql: conn.execute(sql).fetchone()[0]  # noqa: E731
    summary = {
        "as_of": as_of,
        "invoices": {"staged": count("SELECT COUNT(*) FROM stg_invoice"),
                     "loaded": count("SELECT COUNT(*) FROM fct_invoice"),
                     "rejected": count("SELECT COUNT(*) FROM etl_reject WHERE entity='invoice'")},
        "payments": {"staged": count("SELECT COUNT(*) FROM stg_payment"),
                     "loaded": count("SELECT COUNT(*) FROM fct_payment"),
                     "rejected": count("SELECT COUNT(*) FROM etl_reject WHERE entity='payment'")},
        "reject_reasons": {r["reason"]: r["n"] for r in conn.execute(
            "SELECT entity || ':' || reason AS reason, COUNT(*) n FROM etl_reject "
            "GROUP BY entity, reason ORDER BY 1")},
        "invoice_status": {r["status"]: r["n"] for r in conn.execute(
            "SELECT status, COUNT(*) n FROM v_invoice_balance GROUP BY status ORDER BY status")},
        "checks": run_checks(conn),
        "amount_tie_out": amount_tie_out(conn),
    }
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    conn.close()
    return summary
