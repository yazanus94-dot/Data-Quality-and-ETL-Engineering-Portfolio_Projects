"""python run.py [--data data] [--out output] [--as-of YYYY-MM-DD]"""
import argparse
import json

from .pipeline import run


def main(argv=None):
    p = argparse.ArgumentParser(prog="billing_etl", description=__doc__)
    p.add_argument("--data", default="data")
    p.add_argument("--out", default="output")
    p.add_argument("--as-of", default=None, help="aging report date (default: today)")
    args = p.parse_args(argv)
    summary = run(args.data, args.out, args.as_of)
    print(json.dumps(summary, indent=2))
    failed = [c for c in summary["checks"] if c["violations"]] or \
             [k for k, v in summary["amount_tie_out"].items() if not v["balanced"]]
    if failed:
        raise SystemExit(f"Reconciliation failed: {failed}")
    print(f"\nReports written to {args.out}/  (reconciliation.csv, aging_report.csv, rejects.csv, summary.json)")


if __name__ == "__main__":
    main()
