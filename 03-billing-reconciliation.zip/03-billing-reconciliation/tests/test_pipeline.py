import csv
import os
import sqlite3

import pytest

from billing_etl import pipeline as p

DATA = os.path.join(os.path.dirname(__file__), "..", "data")
AS_OF = "2026-10-21"


@pytest.fixture(scope="module")
def result(tmp_path_factory):
    out = tmp_path_factory.mktemp("out")
    summary = p.run(DATA, str(out), AS_OF)
    conn = sqlite3.connect(out / "warehouse.db")
    conn.row_factory = sqlite3.Row
    return summary, conn, out


# ---- parsing --------------------------------------------------------------
def test_parse_cents_is_exact():
    assert p.parse_cents("1200.00") == 120000
    assert p.parse_cents("99.99") == 9999
    assert p.parse_cents("0.1") == 10
    assert p.parse_cents("-50.00") == -5000


@pytest.mark.parametrize("bad", ["", "abc", "1,200.00", "12.345", "1e3"])
def test_parse_cents_rejects_bad_input(bad):
    with pytest.raises(ValueError):
        p.parse_cents(bad)


def test_parse_date():
    assert p.parse_date("2026-09-01") == "2026-09-01"
    with pytest.raises(ValueError):
        p.parse_date("01/09/2026")


# ---- validation rules -------------------------------------------------------
def test_invoice_reject_reasons(result):
    _, conn, _ = result
    reasons = {r["source_key"]: r["reason"] for r in conn.execute(
        "SELECT source_key, reason FROM etl_reject WHERE entity='invoice'")}
    assert reasons == {
        "INV-1002": "duplicate_invoice",
        "INV-1007": "unknown_customer",
        "INV-1008": "due_before_issue",
        "INV-1009": "non_positive_amount",
        "INV-1010": "unsupported_currency",
    }


def test_payment_reject_reasons(result):
    _, conn, _ = result
    reasons = sorted((r["source_key"], r["reason"]) for r in conn.execute(
        "SELECT source_key, reason FROM etl_reject WHERE entity='payment'"))
    assert reasons == [("P-3", "duplicate_payment"), ("P-6", "unknown_invoice"),
                       ("P-7", "currency_mismatch"), ("P-8", "non_positive_amount")]


def test_first_occurrence_of_a_duplicate_is_kept(result):
    _, conn, _ = result
    assert conn.execute("SELECT COUNT(*) FROM fct_invoice WHERE invoice_id='INV-1002'").fetchone()[0] == 1
    assert conn.execute("SELECT COUNT(*) FROM fct_payment WHERE payment_id='P-3'").fetchone()[0] == 1


# ---- reconciliation ---------------------------------------------------------
def test_nothing_is_silently_dropped(result):
    summary, _, _ = result
    for entity in ("invoices", "payments"):
        s = summary[entity]
        assert s["staged"] == s["loaded"] + s["rejected"]


def test_invoice_statuses(result):
    _, conn, _ = result
    status = {r["invoice_id"]: (r["status"], r["balance_cents"]) for r in conn.execute(
        "SELECT * FROM v_invoice_balance")}
    assert status["INV-1001"] == ("paid", 0)
    assert status["INV-1002"] == ("partial", 25050)
    assert status["INV-1003"] == ("overpaid", -10000)
    assert status["INV-1004"] == ("partial", 50000)
    assert status["INV-1005"] == ("unpaid", 150000)
    assert status["INV-1011"] == ("paid", 0)


def test_all_sql_checks_and_tie_outs_pass(result):
    summary, _, _ = result
    assert all(c["violations"] == 0 for c in summary["checks"])
    assert all(v["balanced"] for v in summary["amount_tie_out"].values())


def test_aging_buckets(result):
    _, _, out = result
    rows = {(r["customer_name"], r["currency"]): r for r in csv.DictReader(open(out / "aging_report.csv"))}
    assert float(rows[("Al Noor Trading", "USD")]["days_31_60"]) == 250.50
    assert float(rows[("Petra Logistics", "JOD")]["days_1_30"]) == 700.00
    assert float(rows[("Gulf Supplies LLC", "AED")]["days_1_30"]) == 1500.00
    assert ("Al Noor Trading", "USD") in rows and len(rows) == 3   # overpaid / paid invoices excluded


def test_no_cross_currency_totals(result):
    _, _, out = result
    currencies = [r["currency"] for r in csv.DictReader(open(out / "aging_report.csv"))]
    assert sorted(currencies) == ["AED", "JOD", "USD"]


def test_rerun_is_idempotent(tmp_path):
    a = p.run(DATA, str(tmp_path), AS_OF)
    b = p.run(DATA, str(tmp_path), AS_OF)
    assert a == b


def test_checks_detect_a_broken_load(tmp_path):
    p.run(DATA, str(tmp_path), AS_OF)
    conn = sqlite3.connect(tmp_path / "warehouse.db")
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.execute("INSERT INTO fct_payment VALUES ('P-X','INV-NOPE','2026-10-01',100,'USD')")
    violations = sum(c["violations"] for c in p.run_checks(conn))
    assert violations >= 2   # row-count mismatch + orphan payment
