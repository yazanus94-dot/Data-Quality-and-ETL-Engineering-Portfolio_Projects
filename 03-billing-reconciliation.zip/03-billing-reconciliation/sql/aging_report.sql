-- Accounts-receivable aging by customer and currency, as of :as_of
-- Buckets are based on days past due for invoices that still carry a balance.
SELECT
    c.customer_name,
    i.currency,
    SUM(CASE WHEN julianday(:as_of) - julianday(i.due_date) <= 0               THEN i.balance_cents ELSE 0 END) / 100.0 AS current_not_due,
    SUM(CASE WHEN julianday(:as_of) - julianday(i.due_date) BETWEEN 1 AND 30   THEN i.balance_cents ELSE 0 END) / 100.0 AS days_1_30,
    SUM(CASE WHEN julianday(:as_of) - julianday(i.due_date) BETWEEN 31 AND 60  THEN i.balance_cents ELSE 0 END) / 100.0 AS days_31_60,
    SUM(CASE WHEN julianday(:as_of) - julianday(i.due_date) > 60               THEN i.balance_cents ELSE 0 END) / 100.0 AS days_over_60,
    SUM(i.balance_cents) / 100.0 AS total_outstanding
FROM v_invoice_balance AS i
JOIN dim_customer      AS c ON c.customer_id = i.customer_id
WHERE i.balance_cents > 0
GROUP BY c.customer_name, i.currency
ORDER BY c.customer_name, i.currency;
