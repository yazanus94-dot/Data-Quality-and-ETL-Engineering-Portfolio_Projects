-- Tie-out checks. Every query should return zero rows when the load is healthy.

-- 1. Every staged invoice is either loaded or rejected (nothing silently dropped).
SELECT 'invoice row count mismatch' AS check_name
WHERE (SELECT COUNT(*) FROM stg_invoice)
   <> (SELECT COUNT(*) FROM fct_invoice) + (SELECT COUNT(*) FROM etl_reject WHERE entity = 'invoice');

-- 2. Every staged payment is either loaded or rejected.
SELECT 'payment row count mismatch' AS check_name
WHERE (SELECT COUNT(*) FROM stg_payment)
   <> (SELECT COUNT(*) FROM fct_payment) + (SELECT COUNT(*) FROM etl_reject WHERE entity = 'payment');

-- 3. No payment points at a missing invoice (referential integrity).
SELECT p.payment_id FROM fct_payment p LEFT JOIN fct_invoice i USING (invoice_id) WHERE i.invoice_id IS NULL;

-- 4. Invoice ids are unique in the fact table.
SELECT invoice_id FROM fct_invoice GROUP BY invoice_id HAVING COUNT(*) > 1;
