"""Convenience launcher:  python run.py --as-of 2026-10-21"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from billing_etl.__main__ import main  # noqa: E402

if __name__ == "__main__":
    main()
