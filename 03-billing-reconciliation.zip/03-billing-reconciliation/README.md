# 03 - Billing and payments ETL with reconciliation

Loads invoices, payments and customers from CSV into a small star schema, rejects bad rows with a
reason, and proves the load is complete with reconciliation and tie-out checks. Produces a
per-invoice status report and an accounts-receivable aging report.

## What it demonstrates

| Topic | Where |
|---|---|
| Staging -> validate -> load flow | `src/billing_etl/pipeline.py` |
| Requirements turned into rules (9 reject reasons) | `validate_invoice`, `load_payments` |
| Reject handling with reason codes (nothing silently dropped) | `etl_reject` table, `output/rejects.csv` |
| Data quality: duplicates, referential integrity, currency, dates, amounts | validation rules |
| Exact money handling (integer cents, no floats) | `parse_cents` |
| Reconciliation: invoice vs payment status (paid / partial / unpaid / overpaid) | `v_invoice_balance` view |
| Tie-out checks that must return zero rows | `sql/reconciliation_checks.sql` |
| Aging report in plain SQL | `sql/aging_report.sql` |
| Scheduled run | `.github/workflows/ci.yml` (nightly cron) |
| ETL testing, including a test that proves the checks catch a broken load | `tests/test_pipeline.py` (17 tests) |

## Run it

```bash
pip install -r requirements.txt
python run.py --as-of 2026-10-21     # writes output/: reconciliation.csv, aging_report.csv, rejects.csv, summary.json
pytest
```

The command exits with an error if any reconciliation check or tie-out fails, so a scheduler can
alert on it.

## Business rules

| Entity | Rule | Reject reason |
|---|---|---|
| invoice | amount is a valid decimal | `invalid_amount` |
| invoice | amount greater than zero | `non_positive_amount` |
| invoice | currency in USD, EUR, JOD, AED | `unsupported_currency` |
| invoice | dates valid, due date not before issue date | `invalid_date`, `due_before_issue` |
| invoice | customer exists | `unknown_customer` |
| invoice / payment | id not seen before (first one is kept) | `duplicate_invoice`, `duplicate_payment` |
| payment | invoice exists | `unknown_invoice` |
| payment | currency matches the invoice | `currency_mismatch` |

## Design decisions

* **Full refresh, one transaction.** The target is rebuilt every run, so reruns give identical output.
* **Rejects are data, not logs.** Each rejected row is kept with its raw values and a reason, so the
  business can fix and resubmit it.
* **Money is never summed across currencies.** Reports are grouped by currency.
* **Overpayments are visible.** They show as `overpaid` with a negative balance instead of being hidden.

## Notes

SQLite keeps the project runnable anywhere. The data is synthetic. Porting to SQL Server or
PostgreSQL would mean changing the date functions in the aging query and the view syntax details.

## About this project

A personal learning and portfolio project with synthetic data, built to show my approach to ETL
design, data quality and testing. My professional background is in QA and test automation. It is
not a production system and does not claim experience with any specific enterprise tool.
