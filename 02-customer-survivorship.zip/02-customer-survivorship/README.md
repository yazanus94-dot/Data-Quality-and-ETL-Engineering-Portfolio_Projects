# 02 - Customer matching and survivorship (golden record)

Three source systems (CRM, billing, web sign-ups) hold overlapping, inconsistent customer data.
This pipeline normalises the records, matches the ones that belong to the same person, and applies
**survivorship rules** to build one trusted "golden" record per customer, with lineage showing
which source supplied each field.

## What it demonstrates

| Topic | Where |
|---|---|
| Survivorship rules (priority, recency, completeness) | `src/survivorship/rules.py` |
| Transitive record matching (union-find) | `src/survivorship/match.py` |
| Normalisation and validation | `src/survivorship/normalize.py` |
| Field-level lineage | `lineage` column of the output |
| Data quality report (conflicts, invalid values, merge counts) | `output/dq_report.json` |
| Deterministic, repeatable output (stable golden IDs) | `golden_id()` in `pipeline.py` |
| ETL testing | `tests/test_survivorship.py` (15 tests) |

## Rules in use

| Field | Rule | Why |
|---|---|---|
| name | most trusted source (CRM > billing > web) | system of record for identity |
| email | most recent valid value | people change e-mail; invalid values are excluded |
| phone | most complete (keeps the country code if any source has it) | longer value carries more information |
| address | most recent non-empty value | people move |

Ties on recency fall back to source priority, and ties on priority fall back to recency.

## Run it

```bash
pip install -r requirements.txt
python run.py          # reads data/*.csv, writes output/golden_customer.csv, golden.db, dq_report.json
pytest
```

## Assumptions and limits

* Matching keys are a valid e-mail (case-insensitive) or the last 9 digits of a phone number.
  The phone key assumes 9-digit subscriber numbers; shorter numbers are not used for matching.
* Matching is deterministic. There is no fuzzy name matching, which would need review of
  false positives before it is trusted.
* The data is synthetic. Replace the CSVs in `data/` (same columns) to try other inputs.

## About this project

A personal learning and portfolio project with synthetic data, built to show my approach to ETL
design, data quality and testing. My professional background is in QA and test automation. It is
not a production system and does not claim experience with any specific enterprise tool.
