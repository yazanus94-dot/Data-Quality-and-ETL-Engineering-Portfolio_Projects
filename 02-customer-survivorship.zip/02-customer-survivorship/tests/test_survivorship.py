import json
import os

from survivorship import normalize as n
from survivorship.match import cluster
from survivorship.pipeline import build_golden, read_sources, run
from survivorship.rules import by_priority, most_complete, most_recent, survive

DATA = os.path.join(os.path.dirname(__file__), "..", "data")


def rec(source, sid, **kw):
    base = {"source": source, "source_id": sid, "name": "", "email": "", "phone": "",
            "address": "", "updated_at": "2026-01-01"}
    base.update(kw)
    return base


# ---- normalisation -------------------------------------------------------
def test_phone_formats_share_one_key():
    assert n.phone_key("+962 79 123 4567") == n.phone_key("0791234567") == n.phone_key("00962791234567")


def test_short_phone_is_not_used_for_matching():
    assert n.phone_key("12345") == ""


def test_email_validation_and_normalisation():
    assert n.norm_email("  Lina@Example.COM ") == "lina@example.com"
    assert n.is_valid_email("a.b+c@sub.example.com")
    assert not n.is_valid_email("sara@@example")
    assert not n.is_valid_email("no-at-sign.com")


def test_placeholder_names_are_discarded():
    assert n.clean_name("N/A") == "" and n.clean_name("  ") == ""
    assert n.display_name("LINA HADDAD") == "Lina Haddad"
    assert n.display_name("Lina McDonald") == "Lina McDonald"


# ---- matching --------------------------------------------------------------
def test_matches_on_email_ignoring_case():
    groups = cluster([rec("crm", "1", email="A@x.com"), rec("web", "2", email="a@X.com")])
    assert len(groups) == 1


def test_matching_is_transitive_across_email_and_phone():
    a = rec("crm", "1", email="one@x.com", phone="0791111111")
    b = rec("billing", "2", email="two@x.com", phone="962791111111")   # shares phone with a
    c = rec("web", "3", email="two@x.com")                             # shares email with b
    assert len(cluster([a, b, c])) == 1


def test_invalid_email_never_causes_a_match():
    groups = cluster([rec("crm", "1", email="bad@@x"), rec("web", "2", email="bad@@x")])
    assert len(groups) == 2


# ---- survivorship rules ----------------------------------------------------
def test_name_follows_source_priority_not_recency():
    values, lineage = survive([
        rec("web", "w", name="Newer Web Name", updated_at="2026-05-01"),
        rec("crm", "c", name="Crm Name", updated_at="2026-01-01"),
    ])
    assert values["name"] == "Crm Name" and lineage["name"] == "crm:c"


def test_email_and_address_follow_recency():
    values, lineage = survive([
        rec("crm", "c", email="old@x.com", address="Old St", updated_at="2026-01-01"),
        rec("billing", "b", email="new@x.com", address="New St", updated_at="2026-03-01"),
    ])
    assert values["email"] == "new@x.com" and values["address"] == "New St"
    assert lineage["email"] == "billing:b"


def test_phone_prefers_most_complete_value():
    values, _ = survive([
        rec("crm", "c", phone="0791234567"),
        rec("billing", "b", phone="+962 79 123 4567"),
    ])
    assert values["phone"] == "962791234567"


def test_invalid_values_cannot_survive():
    values, _ = survive([
        rec("crm", "c", email="bad@@x", name="N/A"),
        rec("web", "w", email="good@x.com", name="Real Name"),
    ])
    assert values["email"] == "good@x.com" and values["name"] == "Real Name"


def test_tie_on_recency_falls_back_to_priority():
    value, winner = most_recent([
        {**rec("web", "w", updated_at="2026-02-01"), "_value": "web"},
        {**rec("crm", "c", updated_at="2026-02-01"), "_value": "crm"},
    ])
    assert winner["source"] == "crm"


def test_strategies_return_value_and_winner():
    cands = [{**rec("crm", "c"), "_value": "abc"}, {**rec("web", "w"), "_value": "abcdef"}]
    assert most_complete(cands)[0] == "abcdef"
    assert by_priority(cands)[1]["source"] == "crm"


# ---- end to end on the sample data -----------------------------------------
def test_sample_data_end_to_end(tmp_path):
    golden, report = run(DATA, str(tmp_path))
    assert report["input_total"] == 11
    assert report["golden_records"] == 6
    assert report["invalid_emails"] == 1
    by_email = {g["email"]: g for g in golden}

    lina = by_email["lina@example.com"]
    assert lina["name"] == "Lina Haddad"                      # crm wins on priority
    assert lina["address"] == "12 Rainbow Street, Amman 11181"  # billing is newer
    assert lina["phone"] == "962791234567"
    assert lina["source_records"] == "billing:B101;crm:C001;web:W900"

    omar = by_email["omar.nasser@example.com"]                 # matched via phone, newest email wins
    assert omar["source_records"] == "billing:B102;crm:C002"

    sara = next(g for g in golden if "crm:C003" in g["source_records"])
    assert "web:W901" in sara["source_records"]                # joined by phone despite bad email
    assert sara["email"] == "sara@example.com" and sara["name"] == "Sara Khoury"

    assert os.path.exists(tmp_path / "golden_customer.csv")
    assert json.load(open(tmp_path / "dq_report.json"))["golden_records"] == 6


def test_golden_ids_are_deterministic():
    records = read_sources(DATA)
    a, _ = build_golden(records)
    b, _ = build_golden(list(reversed(records)))
    assert sorted(g["golden_id"] for g in a) == sorted(g["golden_id"] for g in b)
