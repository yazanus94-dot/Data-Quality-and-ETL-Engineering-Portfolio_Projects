"""Survivorship rules: for each attribute, decide which source value survives.

Each strategy takes the candidate records of one customer and returns (value, winning_record).
Strategies only see candidates that are valid for that field (non-empty, valid e-mail, ...).
"""
from .normalize import clean_name, display_name, is_valid_email, norm_email, norm_phone

# Lower number = more trusted system of record.
SOURCE_PRIORITY = {"crm": 1, "billing": 2, "web": 3}


def _priority(rec) -> int:
    return SOURCE_PRIORITY.get(rec["source"], 99)


def by_priority(candidates):
    """Trusted-source rule: best source wins; ties go to the most recent record."""
    best = min(candidates, key=lambda r: (_priority(r), _neg(r["updated_at"])))
    return best["_value"], best


def most_recent(candidates):
    """Recency rule: newest record wins; ties go to the more trusted source."""
    best = min(candidates, key=lambda r: (_neg(r["updated_at"]), _priority(r)))
    return best["_value"], best


def most_complete(candidates):
    """Completeness rule: the longest value wins (e.g. phone with country code)."""
    best = min(candidates, key=lambda r: (-len(r["_value"]), _priority(r)))
    return best["_value"], best


def _neg(text: str):
    """Sort key that orders ISO date strings newest-first."""
    return tuple(-ord(c) for c in text)


# field -> (strategy, extractor that returns a cleaned value or '' if unusable)
RULES = {
    "name": (by_priority, lambda r: display_name(clean_name(r.get("name")))),
    "email": (most_recent, lambda r: norm_email(r.get("email")) if is_valid_email(r.get("email")) else ""),
    "phone": (most_complete, lambda r: norm_phone(r.get("phone"))),
    "address": (most_recent, lambda r: (r.get("address") or "").strip()),
}


def survive(records: list[dict]) -> tuple[dict, dict]:
    """Apply every rule to one cluster. Returns (golden_values, lineage)."""
    values, lineage = {}, {}
    for field, (strategy, extract) in RULES.items():
        candidates = []
        for rec in records:
            value = extract(rec)
            if value:
                candidates.append({**rec, "_value": value})
        if candidates:
            value, winner = strategy(candidates)
            values[field] = value
            lineage[field] = f'{winner["source"]}:{winner["source_id"]}'
        else:
            values[field] = ""
            lineage[field] = ""
    return values, lineage


def conflicts(records: list[dict]) -> dict[str, int]:
    """Count, per field, whether the cluster's usable values disagree (data quality signal)."""
    out = {}
    for field, (_, extract) in RULES.items():
        distinct = {extract(r).lower() for r in records if extract(r)}
        out[field] = 1 if len(distinct) > 1 else 0
    return out
