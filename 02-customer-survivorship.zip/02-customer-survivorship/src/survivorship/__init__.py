"""Customer matching and survivorship: build one golden record from several source systems."""
