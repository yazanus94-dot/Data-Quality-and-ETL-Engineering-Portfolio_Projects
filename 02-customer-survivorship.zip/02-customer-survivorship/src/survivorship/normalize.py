"""Normalisation helpers. Matching quality depends almost entirely on these."""
import re

_EMAIL_RE = re.compile(r"^[a-z0-9._%+\-]+@[a-z0-9\-]+(\.[a-z0-9\-]+)+$")
PLACEHOLDER_NAMES = {"", "n/a", "na", "none", "null", "unknown", "-"}


def norm_email(value: str | None) -> str:
    return (value or "").strip().lower()


def is_valid_email(value: str | None) -> bool:
    return bool(_EMAIL_RE.match(norm_email(value)))


def norm_phone(value: str | None) -> str:
    """Digits only, international '00' prefix removed. '+962 79 123 4567' -> '962791234567'."""
    digits = re.sub(r"\D", "", value or "")
    return digits[2:] if digits.startswith("00") else digits


def phone_key(value: str | None) -> str:
    """Matching key: the last 9 digits, so '0791234567' and '+962791234567' compare equal.

    Assumption (documented in the README): numbers are from a market with 9-digit subscriber
    numbers after the trunk prefix or country code. Shorter numbers are not used for matching.
    """
    digits = norm_phone(value)
    return digits[-9:] if len(digits) >= 9 else ""


def clean_name(value: str | None) -> str:
    name = re.sub(r"\s+", " ", (value or "").strip())
    return "" if name.lower() in PLACEHOLDER_NAMES else name


def display_name(value: str) -> str:
    """Title-case names that arrive in ALL CAPS or all lower case; leave mixed case alone."""
    return value.title() if value.isupper() or value.islower() else value
