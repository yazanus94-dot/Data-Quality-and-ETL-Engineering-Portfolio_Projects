"""python run.py [--data data] [--out output]"""
import argparse
import json

from .pipeline import run


def main(argv=None):
    p = argparse.ArgumentParser(prog="survivorship", description=__doc__)
    p.add_argument("--data", default="data")
    p.add_argument("--out", default="output")
    args = p.parse_args(argv)
    golden, report = run(args.data, args.out)
    print(f"{report['input_total']} source records -> {report['golden_records']} golden records\n")
    for g in golden:
        print(f'{g["golden_id"]}  {g["name"]:<16} {g["email"]:<28} {g["phone"]:<13} <- {g["source_records"]}')
    print("\nData quality report:")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
