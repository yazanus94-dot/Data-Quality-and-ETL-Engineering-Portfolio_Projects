"""Record matching with union-find, so matches are transitive.

A matches B on e-mail and B matches C on phone  =>  A, B and C are one customer.
"""
from collections import defaultdict

from .normalize import is_valid_email, norm_email, phone_key


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[max(ra, rb)] = min(ra, rb)


def cluster(records: list[dict]) -> list[list[dict]]:
    """Group records that share a valid e-mail or a phone key."""
    uf = UnionFind(len(records))
    seen: dict[tuple[str, str], int] = {}
    for i, rec in enumerate(records):
        keys = []
        if is_valid_email(rec.get("email")):
            keys.append(("email", norm_email(rec["email"])))
        pk = phone_key(rec.get("phone"))
        if pk:
            keys.append(("phone", pk))
        for key in keys:
            if key in seen:
                uf.union(i, seen[key])
            else:
                seen[key] = i
    groups: dict[int, list[dict]] = defaultdict(list)
    for i, rec in enumerate(records):
        groups[uf.find(i)].append(rec)
    return [groups[k] for k in sorted(groups)]
