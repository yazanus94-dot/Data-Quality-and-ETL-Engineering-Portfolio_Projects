"""End-to-end pipeline: read sources -> normalise -> match -> survive -> write outputs + DQ report."""
import csv
import hashlib
import json
import os
import sqlite3
from collections import Counter

from .match import cluster
from .normalize import is_valid_email, phone_key
from .rules import conflicts, survive

SOURCES = ("crm", "billing", "web")


def read_sources(data_dir: str) -> list[dict]:
    records = []
    for source in SOURCES:
        path = os.path.join(data_dir, f"{source}.csv")
        with open(path, newline="", encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                records.append({**row, "source": source})
    return records


def golden_id(cluster_records: list[dict]) -> str:
    keys = sorted(f'{r["source"]}:{r["source_id"]}' for r in cluster_records)
    return "G" + hashlib.sha1("|".join(keys).encode()).hexdigest()[:8].upper()


def build_golden(records: list[dict]) -> tuple[list[dict], dict]:
    groups = cluster(records)
    golden, conflict_totals = [], Counter()
    for group in groups:
        values, lineage = survive(group)
        golden.append({
            "golden_id": golden_id(group),
            **values,
            "source_records": ";".join(sorted(f'{r["source"]}:{r["source_id"]}' for r in group)),
            "lineage": json.dumps(lineage, sort_keys=True),
        })
        conflict_totals.update(conflicts(group))

    report = {
        "input_records": dict(Counter(r["source"] for r in records)),
        "input_total": len(records),
        "golden_records": len(golden),
        "records_merged_away": len(records) - len(golden),
        "invalid_emails": sum(1 for r in records if r.get("email") and not is_valid_email(r["email"])),
        "records_without_matchable_phone": sum(1 for r in records if not phone_key(r.get("phone"))),
        "golden_missing_phone": sum(1 for g in golden if not g["phone"]),
        "golden_missing_email": sum(1 for g in golden if not g["email"]),
        "field_conflicts_resolved": dict(conflict_totals),
    }
    return golden, report


def write_outputs(golden: list[dict], report: dict, out_dir: str) -> None:
    os.makedirs(out_dir, exist_ok=True)
    fields = ["golden_id", "name", "email", "phone", "address", "source_records", "lineage"]
    with open(os.path.join(out_dir, "golden_customer.csv"), "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(golden)
    with open(os.path.join(out_dir, "dq_report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    db_path = os.path.join(out_dir, "golden.db")
    conn = sqlite3.connect(db_path)
    conn.execute("DROP TABLE IF EXISTS golden_customer")
    conn.execute("CREATE TABLE golden_customer (golden_id TEXT PRIMARY KEY, name TEXT, email TEXT, "
                 "phone TEXT, address TEXT, source_records TEXT, lineage TEXT)")
    conn.executemany("INSERT INTO golden_customer VALUES (:golden_id,:name,:email,:phone,:address,"
                     ":source_records,:lineage)", golden)
    conn.commit()
    conn.close()


def run(data_dir: str, out_dir: str) -> tuple[list[dict], dict]:
    golden, report = build_golden(read_sources(data_dir))
    write_outputs(golden, report, out_dir)
    return golden, report
